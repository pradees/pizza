package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.connection.CommonConnection;
import com.capgemini.tcc.service.IPatientService;
        


public class PatientDAO implements IPatientDAO {
	private Connection cn;
	private PreparedStatement pst;
	
	
	public int addPatientdetails1(PatientBean patient) {

    	try {
			cn=CommonConnection.getcon();
			 pst=cn.prepareStatement("Insert into patient1 values(Patient_id.nextval ,? ,? ,? ,? ,sysdate)");
			 pst.setString(1,patient.getPatientName());
			 pst.setInt(2,patient.getPatientAge());
			 pst.setLong(3,patient.getPatientPhoneNumber());
			 pst.setString(4,patient.getDescription());
			 pst.executeUpdate();
			 System.out.println("Patient Information stored successfully");				 
		} catch (Exception e) {
			
			e.printStackTrace();
		}
    	   
		return 0;
		}
	/*public class PatientDAO implements IPatientDAO {
		private Connection cn;
*/
		public PatientBean getPatientDetails1(int patientID) {
			
			try
			{
				cn=CommonConnection.getcon();
				Statement st=cn.createStatement();			
				int i=st.executeUpdate("select * from patient1 where patient_id="+patientID);	
				
				
		   	 if(i>0) {
		   		ResultSet rs=st.executeQuery("select * from patient1 where patient_id="+patientID);
		   		
		   		while(rs.next())
		   	 {
		   			System.out.println(i);
		   		 System.out.println("Name of the Patient:"+rs.getString(2)+"\nAge:"+rs.getInt(3)+"\nPhone Number:"+rs.getLong(4)+"\nDescription:"+rs.getString(5)+"\nConsultation Date:"+LocalDate.now());
		   	 }
			} 
		   	 else 
		   	 {
		   		 System.out.println("result not found");
		   	 }
		   	
			} 
			catch (Exception e) 
			{			
				e.printStackTrace();
			}   	 
			return null;
		}

		@Override
		public int addPatientdetails(PatientBean patient) {
			// TODO Auto-generated method stub
			return 0;
		}
	
		

	
	@Override
	public PatientBean getPatientDetails(int patientID) {
		// TODO Auto-generated method stub
		return null;
	}

}
