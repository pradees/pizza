package com.capgemini.tcc.bean;
import java.util.*;

public class PatientBean {
	int PatientId;
	String PatientName;
	int PatientAge;
	long PatientPhoneNumber;
	String Description;
	Date ConsultationDate;
	public int getPatientId() {
		return PatientId;
	}
	public void setPatientId(int patientId) {
		PatientId = patientId;
	}
	public String getPatientName() {
		return PatientName;
	}
	public void setPatientName(String patientName) {
		PatientName = patientName;
	}
	public int getPatientAge() {
		return PatientAge;
	}
	public void setPatientAge(int patientAge) {
		PatientAge = patientAge;
	}
	public long getPatientPhoneNumber() {
		return PatientPhoneNumber;
	}
	public void setPatientPhoneNumber(long patientPhoneNumber) {
		PatientPhoneNumber = patientPhoneNumber;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Date getConsultationDate() {
		return ConsultationDate;
	}
	public void setConsultationDate(Date consultationDate) {
		ConsultationDate = consultationDate;
	}

}
