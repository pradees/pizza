package com.capgemini.tcc.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.connection.CommonConnection;
import com.capgemini.tcc.dao.PatientDAO;

	public class PatientService implements IPatientService
	{

		@Override
		public int addPatientdetails(PatientBean patient) {
			PatientDAO obj=new PatientDAO();
			return 0;
		}

		@Override
		public PatientBean getPatientDetails(int patientID) {
			PatientDAO obj=new PatientDAO();
			return null;
		}
		
	}

